package Project3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JProgressBar;

/**
 * BubbleSort class takes an Array of integers and sorts it via Bubble Sort algorithm
 * Updates a progress bar with the progress of the Array being sorted and outputs 
 * time elapsed to a data file
 * @author Jake Salmon
 * 
 */
public class BubbleSort implements Runnable  {

	private Integer[] data;
	private double progressCount = 0.0;
	private int numberOfPasses = 0;
	private long startTime, finishTime, timeElapsed;
	private JProgressBar bar;
	
	
	
	
	/**
	 * Sorts array by comparing neighbor elements and moving them into the proper 
	 * position or "bubbling" the element to the proper place in the array each pass
	 * @param data
	 * @param bar
	 */
	public BubbleSort(Integer[] data, JProgressBar bar)
	{
		this.data = data;
		this.bar = bar;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run()
	{
		startTime = System.nanoTime();
		bubbleSort();
		finishTime = System.nanoTime();
		timeElapsed = finishTime - startTime;
		outputToFile();
	}
	
private void outputToFile() {
		File outputFile = new File("output.dat");
		try {
			PrintWriter outStream = new PrintWriter(new FileWriter(outputFile, true));
			outStream.append("\nBubbleSort Thread elapsed in " + timeElapsed + " nanoseconds\r");
			outStream.close();
		} catch (IOException e) {
			System.out.println("BubbleSort didn't print");
		}
		
		
	}

	  
	  private void bubbleSort()
  {
      int position, scan;
		
      for (position =  data.length - 1; position >= 0; position--)
      {
    	  //This updates the number off passes every time it goes thru
    	  numberOfPasses++;
    	  getProgress();
          for (scan = 0; scan <= position - 1; scan++)
          {
              if (data[scan].compareTo(data[scan+1]) > 0)
                  swap(scan, scan + 1);
          }
      }
  }

private void swap( int index1, int index2)
{
	int temp = data[index1];
	data[index1] = data[index2];
	data[index2] = temp;
}
	

//This returns an int that represents progress
private void getProgress()
{
	int result;
	
	//formula for getting an int between 1 and 100 for progress
	progressCount = 1 - (((double)data.length - (double)numberOfPasses)/(double)data.length);
	result = (int) (progressCount * 100);
	bar.setValue(result);
	
	
}  
}