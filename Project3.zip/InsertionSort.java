package Project3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JProgressBar;

/**
 * InsertionSort class takes an Array of integers and sorts it via Insertion Sort algorithm
 * Updates a progress bar with the progress of the Array being sorted and outputs 
 * time elapsed to a data file
 * @author Jake Salmon
 *
 */
public class InsertionSort implements Runnable {

	private Integer[] data;
	private double progressCount = 0.0;
	private int numberOfPasses = 0;
	private long startTime, finishTime, timeElapsed;
	JProgressBar bar;
	
	
	
	/**
	 * Constructor
	 * @param data
	 * @param bar
	 */
	public InsertionSort(Integer[] data, JProgressBar bar)
	{
		this.data = data;
		this.bar = bar;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run()
	{
		startTime = System.nanoTime();
		insertionSort();
		finishTime = System.nanoTime();
		timeElapsed = finishTime - startTime;
		outputToFile();
	}
	
	
	
	  /**
	 * Sorts an Array by inserting one element at a time into a "sorted array" into its correct position
	 */
	public void insertionSort()
	    {
	        for (int index = 1; index < data.length; index++)
	        {
	            int key = data[index];
	            int position = index;
				numberOfPasses++;
				getProgress();
	          
	            while (position > 0 && data[position-1].compareTo(key) > 0)
	            {
	                data[position] = data[position-1];
	                position--;
	            }
				
	            data[position] = key;
	        }
	    }
	  
	  private void outputToFile() {
			File outputFile = new File("output.dat");
			try {
				PrintWriter outStream = new PrintWriter(new FileWriter(outputFile, true));
				outStream.append("\nInsertionSort Thread elapsed in " + timeElapsed + " nanoseconds\r");
				outStream.close();
			} catch (IOException e) {
				System.out.println("InsertionSort didn't write.. gg");
			}
			
		}
	  
	  private int getProgress()
	  {
	  	int result;
	  	progressCount = 1 - (((double)data.length - (double)numberOfPasses)/(double)data.length);
	  	result = (int) (progressCount * 100);
	  	bar.setValue(result);
	  	return result;
	  }
	  

	  
}
