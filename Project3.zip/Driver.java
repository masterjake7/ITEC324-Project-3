package Project3;


/**
 * Driver class starts the program
 * @author Jake Salmon
 *
 */
public class Driver {
	
	
	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args)
	{
		View view = new View();
	}
}